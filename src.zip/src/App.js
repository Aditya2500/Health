import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import About from "./app-body/About";
import Details from "./app-body/blog/Details";
import Home from "./app-body/Home";
import Layout from "./Layout";

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Layout>{<Home/>}</Layout>} />
        <Route path="/home" element={<Layout>{<Home/>}</Layout>} />
        <Route exact path="/about" element={<Layout>{<About/>}</Layout>} />
        <Route exact path="/details/:id" element={<Layout>{<Details/>}</Layout>} />
        <Route path="*" element={<Layout>{<Home/>}</Layout>} />
      </Routes>
    </Router>
  );
}

export default App;
