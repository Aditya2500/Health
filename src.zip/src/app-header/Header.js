import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {  faFacebook, faGithub, faTwitter, faInstagram } from '@fortawesome/free-brands-svg-icons';

const Header = ()=>{
return (
    <section className='fixed-top bg-light'>
    <div className="container">
    <header className="d-flex flex-wrap justify-content-center py-3 mb-4 ">
      <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <span className="fs-4 text-warning fw-bold">Health Awareness</span>
      </a>

      <ul className="nav nav-pills">
      <div className='p-2'> <FontAwesomeIcon icon={faFacebook} size="lg" /></div>
      <div className='p-2'> <FontAwesomeIcon icon={faGithub} size="lg" /></div>
      <div className='p-2'> <FontAwesomeIcon icon={faTwitter} size="lg" /></div>
      <div className='p-2'> <FontAwesomeIcon icon={faInstagram} size="lg" /></div>
      </ul>
    </header>
  </div>
  </section>
)
}

export default Header;