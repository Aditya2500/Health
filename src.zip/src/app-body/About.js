import React from 'react';

const About = ()=>{
return (
    <section>
    About
  </section>
)
}

export default About;