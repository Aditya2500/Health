import React from 'react';
import { Link } from "react-router-dom";

const Blog = ({
      articleData: {
        articleId,
        header1,
        header2,
        header3,
        header4,
        header5,
        header6,
        date,
        description,
        img,
      }
})=>{
return (
    <section>
    <div className="row mb-2">
    <div className="col-md-12">
      <div className="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div className="col p-4 d-flex flex-column position-static">
          <h3 style={{color: 'white', background: 'darkslategrey',fontWeight: 'bold'}} className="mb-0"><span style={{color:'#FDFF33'}}>{header1} </span><span>{header2} </span><span style={{color:'#FDFF33'}}>{header3} </span><span>{header4} </span><span style={{color:'#FDFF33'}}>{header5} </span><span className='px-2' style={{background:'red'}}>{header6}</span></h3>
          <div className="mb-1 text-muted">{date}</div>
          <h5 style={{color: '#757575', fonteWight: 'bold'}} className="card-text mb-auto">
            {description[0]}
          </h5>
          <Link to={`/details/${articleId}`}>More</Link>
        </div>
        <div className="col-auto d-none d-lg-block">
        <Link to={`/details/${articleId}`}>
          <img alt="No Thumbnail" width="600" height="350" src={img}  />
        </Link>
        </div>
      </div>
    </div>
  </div>
  </section>
)
}

export default Blog;