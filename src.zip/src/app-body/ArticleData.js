const articleData = [
    {
    articleId: "blog1",
    header1: "Bhasan",
    header2: "Katam Hote Hi",
    header3: "PM Modi",
    header4: "Ne Kiya",
    header5: "Gajab Khel",
    header6: "Dekh Raha Desh",
    date: "Nov 12",
    description: [
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again.",
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again.",
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again."
    ],
    img: `https://cdn.britannica.com/60/8160-050-08CCEABC/German-shepherd.jpg`
},
{
    articleId: "blog2",
    header1: "Bhasan",
    header2: "Katam Hote Hi",
    header3: "PM Modi",
    header4: "Ne Kiya",
    header5: "Gajab Khel",
    header6: "Dekh Raha Desh",
    date: "Nov 12",
    description: [
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again.",
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again.",
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again."
    ],
    img: `https://i.insider.com/5484d9d1eab8ea3017b17e29?width=600&format=jpeg&auto=webp`
},
{
    articleId: "blog3",
    header1: "Bhasan",
    header2: "Katam Hote Hi",
    header3: "PM Modi",
    header4: "Ne Kiya",
    header5: "Gajab Khel",
    header6: "Dekh Raha Desh",
    date: "Nov 12",
    description: [
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again.",
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again.",
        "The young child who is urinating frequently, drinking large quantities, losing weight, and becoming more and more tired and ill is the classic picture of a child with new-onset type 1 diabetes. If a child who is potty-trained and dry at night starts having accidents and wetting the bed again."
    ],
    img: `https://cdn.britannica.com/60/8160-050-08CCEABC/German-shepherd.jpg`
}
]

export default articleData;