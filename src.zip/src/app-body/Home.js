import React from 'react';
import Blog from './blog/Blog';
import articleData from '../app-body/ArticleData';

const Home = ()=>{
return (
    <section>
      {articleData.map((articleData)=>
      <Blog
        articleData={articleData}
      />
      )}
  </section>
)
}

export default Home;