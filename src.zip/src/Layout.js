import React from 'react';
import Header from "./app-header/Header";
import Footer from "./app-footer/Footer";

const Layout = ({children})=>{
return (
  <div className='container'>
      <Header/>
      <section style={{marginTop: '110px'}}>
        {children}
      </section>
      <Footer/>
  </div>
)
}

export default Layout;