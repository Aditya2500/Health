import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {  faFacebook, faGithub, faTwitter, faInstagram } from '@fortawesome/free-brands-svg-icons';

const Footer = ()=>{
return (
    <section>
  <footer className="text-center border">
  <div className="container p-4 pb-0">
    <section className="mb-4">
       <div  className='d-flex justify-content-center'>
       <div className='p-2'> <FontAwesomeIcon icon={faFacebook} size="lg" /></div>
      <div className='p-2'> <FontAwesomeIcon icon={faGithub} size="lg" /></div>
      <div className='p-2'> <FontAwesomeIcon icon={faTwitter} size="lg" /></div>
      <div className='p-2'> <FontAwesomeIcon icon={faInstagram} size="lg" /></div>
       </div>

      
    </section>
  </div>

  <div className="text-center p-3">
    © 2022 Copyright: Health Awareness
  </div>
</footer>
</section>
)
}

export default Footer;